# TEXNO-TELEKOM 1.0

A new Android app starter built with Kotlin and Jetpack Compose.

## Included in this first build
- Dark navy / blue visual identity
- Home screen and app catalogue sample cards
- Search and category filters
- Bottom navigation shell for Home, Apps, Notifications and Profile

## Build APK
Open this folder in Android Studio (Hedgehog or newer), allow Gradle sync, then select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

The debug APK will be generated at `app/build/outputs/apk/debug/app-debug.apk`.

## Important
The catalogue currently contains demonstration entries. Real APK downloads, admin authentication, push notifications and Firebase require the owner's service configuration and should be connected before public release. No passwords or signing keys are included.
