package az.texnotelekom.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF090F1E)
private val Panel = Color(0xFF121D32)
private val Blue = Color(0xFF3987FF)
private val Muted = Color(0xFF9AAAC4)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TexnoApp() }
    }
}

data class AppItem(val title: String, val category: String, val description: String, val badge: String)

@Composable
fun TexnoApp() {
    var query by remember { mutableStateOf("") }
    var selectedTab by remember { mutableStateOf("Ana səhifə") }
    var selectedCategory by remember { mutableStateOf("Hamısı") }
    val apps = listOf(
        AppItem("WhatsApp", "Rabitə", "Mesajlaşma tətbiqi", "POPULYAR"),
        AppItem("Telegram", "Rabitə", "Sürətli mesajlaşma və kanallar", "YENİLƏNİB"),
        AppItem("YouTube", "Media", "Video və əyləncə platforması", "SEÇİLMİŞ"),
        AppItem("Fayl meneceri", "Alətlər", "Faylları rahat idarə et", "ALƏT")
    )
    val filtered = apps.filter {
        (selectedCategory == "Hamısı" || it.category == selectedCategory) &&
            (it.title.contains(query, true) || it.description.contains(query, true))
    }

    MaterialTheme(colorScheme = darkColorScheme(background = Navy, surface = Panel, primary = Blue)) {
        Scaffold(containerColor = Navy, bottomBar = {
            NavigationBar(containerColor = Panel, contentColor = Color.White) {
                listOf("Ana səhifə", "Tətbiqlər", "Bildirişlər", "Profil").forEachIndexed { index, label ->
                    val icon = when (index) { 0 -> Icons.Default.Home; 1 -> Icons.Default.Apps; 2 -> Icons.Default.Notifications; else -> Icons.Default.Person }
                    NavigationBarItem(selected = selectedTab == label, onClick = { selectedTab = label },
                        icon = { Icon(icon, contentDescription = label) }, label = { Text(label, fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = Blue, selectedTextColor = Blue,
                            indicatorColor = Blue.copy(alpha = .15f), unselectedIconColor = Muted, unselectedTextColor = Muted))
                }
            }
        }) { padding ->
            LazyColumn(modifier = Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(46.dp).background(Brush.linearGradient(listOf(Blue, Color(0xFF6C5CE7))), RoundedCornerShape(15.dp)), contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Bolt, null, tint = Color.White, modifier = Modifier.size(29.dp))
                            }
                            Spacer(Modifier.width(11.dp))
                            Column {
                                Text("TEXNO-TELEKOM", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                                Text("Texnologiya bir addım öndə", color = Muted, fontSize = 11.sp)
                            }
                        }
                        IconButton(onClick = { selectedTab = "Bildirişlər" }) {
                            Icon(Icons.Default.NotificationsNone, "Bildirişlər", tint = Color.White)
                        }
                    }
                }
                item {
                    Box(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF173D79), Color(0xFF25215A))), RoundedCornerShape(24.dp)).padding(20.dp)) {
                        Column {
                            Text("XOŞ GƏLMİSƏN!", color = Color(0xFF9CC5FF), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                            Spacer(Modifier.height(8.dp))
                            Text("Rəqəmsal dünyanı\nkəşf et.", color = Color.White, fontSize = 27.sp, lineHeight = 32.sp, fontWeight = FontWeight.ExtraBold)
                            Spacer(Modifier.height(8.dp))
                            Text("Seçilmiş tətbiqlər və texnoloji yeniliklər bir məkanda.", color = Color(0xFFD2DDF2), fontSize = 13.sp)
                            Spacer(Modifier.height(16.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Explore, null, tint = Color.White, modifier = Modifier.size(17.dp))
                                Spacer(Modifier.width(7.dp))
                                Text("Kəşfə başla", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }
                    }
                }
                item {
                    OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Tətbiq axtar...", color = Muted) }, leadingIcon = { Icon(Icons.Default.Search, null, tint = Muted) },
                        trailingIcon = { if (query.isNotEmpty()) IconButton(onClick = { query = "" }) { Icon(Icons.Default.Close, null, tint = Muted) } },
                        singleLine = true, shape = RoundedCornerShape(16.dp), colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = Blue,
                            unfocusedBorderColor = Color(0xFF263651), focusedContainerColor = Panel, unfocusedContainerColor = Panel))
                }
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Kateqoriyalar", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text("Hamısına bax", color = Blue, fontSize = 12.sp, modifier = Modifier.clickable { selectedTab = "Tətbiqlər" })
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Hamısı", "Rabitə", "Media", "Alətlər").forEach { category ->
                            FilterChip(selected = selectedCategory == category, onClick = { selectedCategory = category }, label = { Text(category) },
                                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Blue, selectedLabelColor = Color.White,
                                    containerColor = Panel, labelColor = Muted), border = FilterChipDefaults.filterChipBorder(enabled = true, selected = selectedCategory == category, borderColor = Color(0xFF263651), selectedBorderColor = Blue))
                        }
                    }
                }
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Seçilmiş tətbiqlər", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Icon(Icons.Default.ArrowForward, null, tint = Blue)
                    }
                }
                items(filtered) { app ->
                    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).clickable { }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(48.dp).background(Color(0xFF20385D), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Android, null, tint = Color(0xFF77D69A), modifier = Modifier.size(27.dp))
                        }
                        Spacer(Modifier.width(13.dp))
                        Column(Modifier.weight(1f)) {
                            Text(app.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text(app.description, color = Muted, fontSize = 11.sp)
                            Spacer(Modifier.height(5.dp))
                            Text(app.badge, color = Blue, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        }
                        Icon(Icons.Default.ChevronRight, null, tint = Muted)
                    }
                }
                if (filtered.isEmpty()) item { Text("Axtarışa uyğun tətbiq tapılmadı.", color = Muted, modifier = Modifier.padding(12.dp)) }
                item {
                    Row(Modifier.fillMaxWidth().background(Color(0xFF102A2A), RoundedCornerShape(16.dp)).padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Info, null, tint = Color(0xFF65D6B2))
                        Spacer(Modifier.width(10.dp))
                        Text("TEXNO-TELEKOM 1.0 • İlkin buraxılış", color = Color(0xFFB5E9D9), fontSize = 11.sp)
                    }
                }
            }
        }
    }
}
